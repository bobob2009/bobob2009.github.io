Helios 1.5 by HTML5 UP
html5up.net | @n33co
Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)


This is Helios, a brand new site template for HTML5 UP. It's clean, modern, and designed
to take advantage of larger (well, wider) displays while still being capable of gracefully
scaling down to fit all manner of smaller ones.
	
Demo images* courtesy of Michael Domaradzki, an awesome photographer I know over at
deviantART. Check out his portfolio here:

http://mdomaradzki.deviantart.com/

* Not included with this download (replaced with generic placeholder images). Please
don't use his work without his permission.

AJ
n33.co @n33co dribbble.com/n33


Credits

	Images (Demo Only)
		Michael Domaradzki (http://mdomaradzki.deviantart.com/)
		
	Icons
		Font Awesome (http://fortawesome.github.com/Font-Awesome/)

	Other
		jQuery (jquery.com)
		html5shiv.js (@afarkas @jdalton @jon_neal @rem)
		jquery.dropotron (n33.co)
		CSS3 Pie (css3pie.com)
		background-size-polyfill (github.com/louisremi/background-size-polyfill)
		skelJS (skeljs.org)