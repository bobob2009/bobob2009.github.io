$(document).ready(function() {
  $('.dropdown-toggle').dropdown();
  $('[data-toggle=tooltip]').tooltip();
});